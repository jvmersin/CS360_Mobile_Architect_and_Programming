package com.jamesehrenberginventoryapp;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface InventoryDao {
    @Query("SELECT * FROM inventory")
    List<Inventory> getAllInventoryItems();

    @Query("SELECT * FROM inventory WHERE id = :id LIMIT 1")
    List<Inventory> findById(int id);

    @Insert
    long insert(Inventory inventory);

    @Update
    void update(Inventory inventory);

    @Delete
    void delete(Inventory inventory);
}

