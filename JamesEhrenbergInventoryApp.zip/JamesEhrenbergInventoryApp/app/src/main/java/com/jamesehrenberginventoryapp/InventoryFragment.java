package com.jamesehrenberginventoryapp;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class InventoryFragment extends Fragment {
    private RecyclerView recyclerView;
    private InventoryAdapter inventoryAdapter;
    private AppDatabase appDatabase;
    private ExecutorService executorService;

    public InventoryFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_inventory, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        FloatingActionButton fabAddItem = view.findViewById(R.id.fab_add_item);
        appDatabase = AppDatabaseSingleton.getDatabase(requireContext().getApplicationContext());
        executorService = Executors.newSingleThreadExecutor();

        fabAddItem.setOnClickListener(v -> addNewInventoryItem());

        loadInventoryItems();

        return view;
    }

    private void loadInventoryItems() {
        executorService.execute(() -> {
            List<Inventory> inventoryList = appDatabase.inventoryDao().getAllInventoryItems();
            // Post data to the main thread
            requireActivity().runOnUiThread(() -> {
                inventoryAdapter = new InventoryAdapter(inventoryList, this::onEditButtonClicked);
                recyclerView.setAdapter(inventoryAdapter);
            });
        });
    }

    private void onEditButtonClicked(Inventory inventory) {
        // Navigate to ItemFragment and pass the selected inventory item as an argument
        Bundle bundle = new Bundle();
        bundle.putInt("inventoryId", inventory.getId());

        ItemFragment itemFragment = new ItemFragment();
        itemFragment.setArguments(bundle);

        requireActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.nav_host_fragment, itemFragment)
                .addToBackStack(null)
                .commit();
    }

    private void addNewInventoryItem() {
        executorService.execute(() -> {
            // Create a new blank Inventory item
            Inventory newInventoryItem = new Inventory("", "", "0", "");

            // Insert the new item and get the generated ID
            long newItemId = appDatabase.inventoryDao().insert(newInventoryItem);

            // Navigate to the ItemFragment with the new item's ID
            requireActivity().runOnUiThread(() -> navigateToItemFragment((int) newItemId));
        });
    }

    private void navigateToItemFragment(int itemId) {
        Bundle bundle = new Bundle();
        bundle.putInt("inventoryId", itemId);

        ItemFragment itemFragment = new ItemFragment();
        itemFragment.setArguments(bundle);

        requireActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.nav_host_fragment, itemFragment)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (executorService != null) {
            executorService.shutdown(); // Shutdown the executor to avoid memory leaks
        }
    }
}