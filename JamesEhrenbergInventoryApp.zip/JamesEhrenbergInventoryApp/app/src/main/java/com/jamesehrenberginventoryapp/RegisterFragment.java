package com.jamesehrenberginventoryapp;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RegisterFragment extends Fragment {
    private EditText emailEdit, firstNameEdit, lastNameEdit, passwordEdit, verifyPasswordEdit;
    private AppDatabase appDatabase;
    private ExecutorService executorService;

    public RegisterFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        Button registerBtn = view.findViewById(R.id.registerButton);
        Button loginBtn = view.findViewById(R.id.existingAccountButton);

        emailEdit = view.findViewById(R.id.emailTextField);
        firstNameEdit = view.findViewById(R.id.firstNameTextField);
        lastNameEdit = view.findViewById(R.id.lastNameTextField);
        passwordEdit = view.findViewById(R.id.passwordTextField);
        verifyPasswordEdit = view.findViewById(R.id.verifyPasswordTextField);
        appDatabase = AppDatabaseSingleton.getDatabase(requireContext().getApplicationContext());
        executorService = Executors.newSingleThreadExecutor();

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEdit.getText().toString();
                String firstName = firstNameEdit.getText().toString();
                String lastName = lastNameEdit.getText().toString();
                String password = passwordEdit.getText().toString();
                String verifyPass = verifyPasswordEdit.getText().toString();

                if (validateFields(email, firstName, lastName, password, verifyPass)) {
                    executorService.execute(() -> registerUser(email, firstName, lastName, password));
                } else {
                    Toast.makeText(getContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_registerFragment_to_loginFragment);
            }
        });

        return view;
    }

    private boolean validateFields(String email, String firstName, String lastName, String password, String verifyPassword) {
        if (email.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || password.isEmpty() || verifyPassword.isEmpty()) {
            showToast("All fields must be filled.");
            return false;
        }

        if (!password.equals(verifyPassword)) {
            showToast("Passwords do not match.");
            return false;
        }

        return true;
    }

    private void registerUser(String email, String firstName, String lastName, String password) {
        User existingUser = appDatabase.userDao().findByEmail(email);

        // We need to switch back to the main thread to update the UI
        Handler mainHandler = new Handler(Looper.getMainLooper());


        if (existingUser != null) {
            mainHandler.post(() -> showToast("Email is already registered."));
        } else {
            // Generate salt and hash the password
            String salt = PasswordUtils.getSalt();
            String hashedPassword = PasswordUtils.hashPassword(password, salt);

            try {
                // Create new user and insert into database
                User newUser = new User(firstName, lastName, email, hashedPassword, salt);
                appDatabase.userDao().insert(newUser);
                mainHandler.post(() -> {
                    showToast("Registration successful. Please log in.");
                    navigateToLogin();
                });
            } catch (Exception e) {
                mainHandler.post(() -> showToast("Registration failed: " + e.getMessage()));
            }
        }
    }

    private void showToast(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }

    private void navigateToLogin() {
        requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment, new LoginFragment()).addToBackStack(null).commit();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (executorService != null) {
            executorService.shutdown(); // Shutdown the executor to avoid memory leaks
        }
    }
}