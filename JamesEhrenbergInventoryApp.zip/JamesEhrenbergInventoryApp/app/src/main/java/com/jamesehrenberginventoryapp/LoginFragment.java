package com.jamesehrenberginventoryapp;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LoginFragment extends Fragment {
    private EditText emailEdit, passwordEdit;
    private AppDatabase appDatabase;
    private ExecutorService executorService;

    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        Button registerBtn = view.findViewById(R.id.newAccountButton);
        Button loginBtn = view.findViewById(R.id.loginButton);

        emailEdit = view.findViewById(R.id.emailTextField);
        passwordEdit = view.findViewById(R.id.passwordTextField);
        appDatabase = AppDatabaseSingleton.getDatabase(requireContext().getApplicationContext());
        executorService = Executors.newSingleThreadExecutor();

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_loginFragment_to_registerFragment);
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEdit.getText().toString();
                String password = passwordEdit.getText().toString();

                if (!email.isEmpty() && !password.isEmpty()) {
                    executorService.execute(() -> loginUser(email, password));
                } else {
                    Toast.makeText(getContext(), "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Log all users in the database for verification
        logAllUsers();
    }

    private void loginUser(String email, String enteredPassword) {
        User user = appDatabase.userDao().findByEmail(email);

        // We need to switch back to the main thread to update the UI
        Handler mainHandler = new Handler(Looper.getMainLooper());


        if (user != null) {
            // User found, now hash the entered password and compare it with the stored password
            String hashedEnteredPassword = PasswordUtils.hashPassword(enteredPassword, user.getSalt());

            if (hashedEnteredPassword.equals(user.getPassword())) {
                // Password matches, navigate to InventoryFragment
                navigateToInventory();
            } else {
                // Password does not match
                mainHandler.post(() -> Toast.makeText(getContext(), "Incorrect password", Toast.LENGTH_SHORT).show());
            }
        } else {
            // No user found with that email
            mainHandler.post(() -> Toast.makeText(getContext(), "User not found", Toast.LENGTH_SHORT).show());
        }
    }

    private void logAllUsers() {
        executorService.execute(() -> {
            List<User> users = appDatabase.userDao().getAll();

            for (User user : users) {
                Log.d("LoginFragment", "User: " + user.getEmail() + ", FirstName: " + user.getFirstName() + ", LastName: " + user.getLastName());
            }
        });
    }

    private void navigateToInventory() {
        requireActivity().getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment, new InventoryFragment()).addToBackStack(null).commit();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (executorService != null) {
            executorService.shutdown(); // Shutdown the executor to avoid memory leaks
        }
    }
}
