package com.jamesehrenberginventoryapp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ItemFragment extends Fragment {

    private EditText titleEditText, descriptionEditText, quantityEditText;
    private ImageView imageView;
    private Button saveButton, deleteButton;
    private AppDatabase appDatabase;
    private ExecutorService executorService;
    private int inventoryId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_item, container, false);

        titleEditText = view.findViewById(R.id.titleEditText);
        descriptionEditText = view.findViewById(R.id.descriptionEditText);
        quantityEditText = view.findViewById(R.id.quantityEditText);
        imageView = view.findViewById(R.id.imageView);
        saveButton = view.findViewById(R.id.saveButton);
        deleteButton = view.findViewById(R.id.deleteButton);

        appDatabase = AppDatabaseSingleton.getDatabase(requireContext().getApplicationContext());
        executorService = Executors.newSingleThreadExecutor();

        if (getArguments() != null) {
            inventoryId = getArguments().getInt("inventoryId");
            loadInventoryItem(inventoryId);
        }

        saveButton.setOnClickListener(v -> saveInventoryItem());
        deleteButton.setOnClickListener(v -> deleteInventoryItem());

        return view;
    }

    private void loadInventoryItem(int id) {
        executorService.execute(() -> {
            List<Inventory> inventory = appDatabase.inventoryDao().findById(id);
            requireActivity().runOnUiThread(() -> {
                if (inventory != null) {
                    titleEditText.setText(inventory.get(0).getItemName());
                    descriptionEditText.setText(inventory.get(0).getDescription());
                    quantityEditText.setText(String.valueOf(inventory.get(0).getQuantity()));
                    // Load image using Glide or Picasso
                    // TODO: replace the placeholder image with images from the app storage in a real application
                }
            });
        });
    }

    private void saveInventoryItem() {
        String title = titleEditText.getText().toString();
        String description = descriptionEditText.getText().toString();
        String quantity = quantityEditText.getText().toString();

        executorService.execute(() -> {
            Inventory inventory = new Inventory(title, description, quantity, "");
            inventory.setId(inventoryId); // Set the ID to update the correct record
            appDatabase.inventoryDao().update(inventory);

            // Navigate back to InventoryFragment after saving
            requireActivity().runOnUiThread(() -> {
                requireActivity().getSupportFragmentManager().popBackStack();
            });
        });
    }

    private void deleteInventoryItem() {
        executorService.execute(() -> {
            List<Inventory> inventory = appDatabase.inventoryDao().findById(inventoryId);
            if (inventory != null) {
                appDatabase.inventoryDao().delete(inventory.get(0));

                // Navigate back to InventoryFragment after deletion
                requireActivity().runOnUiThread(() -> {
                    requireActivity().getSupportFragmentManager().popBackStack();
                });
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (executorService != null) {
            executorService.shutdown();
        }
    }
}
