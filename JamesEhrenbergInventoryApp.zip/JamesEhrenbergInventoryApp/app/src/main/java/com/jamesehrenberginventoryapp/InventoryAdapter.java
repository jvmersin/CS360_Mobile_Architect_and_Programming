package com.jamesehrenberginventoryapp;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {
    private List<Inventory> inventoryList;
    private OnEditButtonClickListener onEditButtonClickListener;

    public interface OnEditButtonClickListener {
        void onEditButtonClicked(Inventory inventory);
    }

    public InventoryAdapter(List<Inventory> inventoryList, OnEditButtonClickListener onEditButtonClickListener) {
        this.inventoryList = inventoryList;
        this.onEditButtonClickListener = onEditButtonClickListener;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_card, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        Inventory inventory = inventoryList.get(position);
        String quantity = "Qty: " + inventory.getQuantity();

        holder.titleTextView.setText(inventory.getItemName());
        holder.descriptionTextView.setText(inventory.getDescription());
        holder.quantityTextView.setText(quantity);

        // Load image from imagePath (you can use Glide or Picasso here)
        // Example: Glide.with(holder.itemView.getContext()).load(inventory.getImagePath()).into(holder.imageView);

        holder.editButton.setOnClickListener(v -> onEditButtonClickListener.onEditButtonClicked(inventory));
    }

    @Override
    public int getItemCount() {
        return inventoryList.size();
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView, descriptionTextView, quantityTextView, editButton;
        ImageView imageView;

        InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.textViewTitle);
            descriptionTextView = itemView.findViewById(R.id.textViewDescription);
            quantityTextView = itemView.findViewById(R.id.textViewQuantity);
            imageView = itemView.findViewById(R.id.imageView);
            editButton = itemView.findViewById(R.id.textViewEdit);
        }
    }
}
