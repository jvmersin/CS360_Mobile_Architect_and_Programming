package com.jamesehrenberginventoryapp;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "inventory")
public class Inventory {
    @PrimaryKey(autoGenerate = true)
    public int id;

    @ColumnInfo(name = "item_name")
    public String itemName;

    @ColumnInfo(name = "description")
    public String description;

    @ColumnInfo(name = "quantity")
    public String quantity;

    @ColumnInfo(name = "image")
    public String image;

    // Constructor
    public Inventory(String itemName, String description, String quantity, String image) {
        this.itemName = itemName;
        this.description = description;
        this.quantity = quantity;
        this.image = image;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public String getDescription() {
        return description;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getImage() {
        return image;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public void setImage(String image) {
        this.image = image;
    }
}