package com.jamesehrenberginventoryapp;

public class Card {
    private String title;
    private String description;
    private String quantity;
    private String imgPath;

    public Card(String title, String description, String quantity, String imgPath) {
        this.title = title;
        this.description = description;
        this.quantity = quantity;
        this.imgPath = imgPath;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public String getQuantity() {
        return this.quantity;
    }

    public String getImgPath() {
        return this.imgPath;
    }
}
