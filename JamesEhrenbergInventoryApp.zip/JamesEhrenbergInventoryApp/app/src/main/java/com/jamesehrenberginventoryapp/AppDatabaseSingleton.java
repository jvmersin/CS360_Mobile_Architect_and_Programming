package com.jamesehrenberginventoryapp;

import android.content.Context;

import androidx.room.Room;

public class AppDatabaseSingleton {
    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabaseSingleton.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "inventory_io").build();
                }
            }
        }
        return INSTANCE;
    }
}
